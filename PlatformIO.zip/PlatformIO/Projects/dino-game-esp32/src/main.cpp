#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ---------------- OLED setup ----------------
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// ---------------- Pins ----------------
#define BUTTON_PIN 4
#define BUZZER_PIN 5   // change pin if needed
#define SDA_PIN 21
#define SCL_PIN 22

// ---------------- Game variables ----------------
bool trexJumping = false;
int trexY = 48;
int jumpVelocity = 0;
int gravity = 1;
int score = 0;
bool gameOver = false;

unsigned long lastObstacleMove = 0;
int obstacleX = 128;

// ---------------- Sound helpers using LEDC ----------------
void soundJump() {
  ledcSetup(0, 1000, 10);        // channel 0, 1kHz, 10-bit resolution
  ledcAttachPin(BUZZER_PIN, 0);
  ledcWriteTone(0, 1000);        // play 1kHz
  delay(120);
  ledcWriteTone(0, 0);           // stop
}

void soundScore() {
  ledcSetup(0, 700, 10);
  ledcAttachPin(BUZZER_PIN, 0);
  ledcWriteTone(0, 700);         // play 700Hz
  delay(100);
  ledcWriteTone(0, 0);
}

void soundGameOver() {
  int notes[]    = { 440, 349, 294, 262 };   // A4, F4, D4, C4
  int duration[] = { 300, 300, 300, 600 };

  ledcSetup(0, 1000, 10);
  ledcAttachPin(BUZZER_PIN, 0);

  for (int i = 0; i < 4; i++) {
    ledcWriteTone(0, notes[i]);  // play note
    delay(duration[i]);
    ledcWriteTone(0, 0);         // short pause
    delay(50);
  }
}

// ---------------- Draw helpers ----------------
void drawTrex() {
  display.fillRect(10, trexY, 10, 10, SSD1306_WHITE); // simple square Dino
}

void drawGround() {
  display.drawLine(0, 58, SCREEN_WIDTH, 58, SSD1306_WHITE);
}

void drawObstacle() {
  display.fillRect(obstacleX, 48, 8, 10, SSD1306_WHITE);
}

// ---------------- Game Over ----------------
void showGameOver() {
  display.clearDisplay();
  display.setTextSize(2);
  display.setCursor(20, 20);
  display.println("GAME OVER");
  display.setTextSize(1);
  display.setCursor(25, 50);
  display.print("Score: ");
  display.println(score);
  display.display();   // draw message first

  soundGameOver();     // play buzzer right after message
}

// ---------------- Setup ----------------
void setup() {
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(BUZZER_PIN, OUTPUT);
  Wire.begin(SDA_PIN, SCL_PIN);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    for (;;); // Halt if display not found
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Starting Dino Game...");
  display.display();
  delay(2000);

  randomSeed(analogRead(0));
}

// ---------------- Main Loop ----------------
void loop() {
  if (gameOver) {
    if (digitalRead(BUTTON_PIN) == LOW) {
      // Reset game
      gameOver = false;
      trexY = 48;
      obstacleX = 128;
      score = 0;
      display.clearDisplay();
      delay(500);
    }
    return;
  }

  // ---- Jump ----
  if (digitalRead(BUTTON_PIN) == LOW && !trexJumping) {
    trexJumping = true;
    jumpVelocity = -10;
    soundJump();
  }

  if (trexJumping) {
    trexY += jumpVelocity;
    jumpVelocity += gravity;
    if (trexY >= 48) {
      trexY = 48;
      trexJumping = false;
    }
  }

  // ---- Obstacle movement ----
  if (millis() - lastObstacleMove > 30) {
    obstacleX -= 3;
    lastObstacleMove = millis();
    if (obstacleX < -10) {
      obstacleX = 128;
      score++;
      soundScore();
    }
  }

  // ---- Collision check ----
  if (obstacleX < 20 && obstacleX > 2 && trexY > 38) {
    gameOver = true;
    showGameOver();  // message + buzzer
    return;
  }

  // ---- Drawing ----
  display.clearDisplay();
  drawGround();
  drawTrex();
  drawObstacle();

  // Score
  display.setTextSize(1);
  display.setCursor(100, 0);
  display.print(score);

  display.display();
}
