#include <TFT_eSPI.h>
#include <SPI.h>

// Game constants
#define SCREEN_WIDTH 240
#define SCREEN_HEIGHT 135
#define GROUND_HEIGHT 20
#define GROUND_LEVEL (SCREEN_HEIGHT - GROUND_HEIGHT)
#define DINO_WIDTH 20
#define DINO_HEIGHT 30
#define OBSTACLE_MIN_HEIGHT 15
#define OBSTACLE_MAX_HEIGHT 25
#define OBSTACLE_MIN_WIDTH 10
#define OBSTACLE_MAX_WIDTH 20
#define OBSTACLE_SPEED 3
#define GRAVITY 0.6
#define JUMP_FORCE -10

// Game states
#define STATE_PLAYING 0
#define STATE_GAME_OVER 1

// Pin definitions (from diagram.json)
#define BUTTON_PIN 5      // btn1 connected to GPIO5
#define BUZZER_PIN 13     // bz1 connected to GPIO13
#define TFT_CS 15         // LCD CS connected to GPIO15
#define TFT_DC 2          // LCD D/C connected to GPIO2
#define TFT_RST 4         // LCD RST connected to GPIO4

TFT_eSPI tft = TFT_eSPI();

// Game variables
int gameState = STATE_PLAYING;
int dinoX = 30;
int dinoY = GROUND_LEVEL - DINO_HEIGHT;
float dinoVelocity = 0;
bool isJumping = false;
int score = 0;
int highScore = 0;
unsigned long lastScoreTime = 0;

// Obstacle structure
struct Obstacle {
  int x;
  int y;
  int width;
  int height;
  bool active;
};

Obstacle obstacles[3]; // Maximum 3 obstacles on screen

// Function prototypes
void drawGround();
void drawDino();
void updateGame();
void resetGame();
void playJumpSound();
void playGameOverSound();
void updateObstacles();
void spawnObstacle();
bool checkCollision();
void updateScore();
void drawScore();
void gameOver();

void setup() {
  Serial.begin(115200);
  
  // Initialize display with custom pins
  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_BLACK);
  
  // Initialize button
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  
  // Initialize buzzer
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);
  
  // Initialize obstacles
  for (int i = 0; i < 3; i++) {
    obstacles[i].active = false;
  }
  
  // Draw initial ground
  drawGround();
  
  // Draw dino
  drawDino();
  
  // Display start message
  tft.setTextColor(TFT_WHITE);
  tft.setTextSize(2);
  tft.setCursor(50, 50);
  tft.print("Press to start!");
}

void loop() {
  static unsigned long lastUpdate = 0;
  unsigned long currentTime = millis();
  
  // Game loop running at ~60fps
  if (currentTime - lastUpdate >= 16) {
    lastUpdate = currentTime;
    
    switch (gameState) {
      case STATE_PLAYING:
        updateGame();
        break;
      case STATE_GAME_OVER:
        // Check for restart
        if (digitalRead(BUTTON_PIN) == LOW) {
          resetGame();
          gameState = STATE_PLAYING;
          delay(200); // Debounce
        }
        break;
    }
  }
}

void updateGame() {
  // Clear previous frame
  tft.fillRect(0, 0, SCREEN_WIDTH, GROUND_LEVEL, TFT_BLACK);
  
  // Handle jumping
  if (digitalRead(BUTTON_PIN) == LOW && !isJumping) {
    dinoVelocity = JUMP_FORCE;
    isJumping = true;
    playJumpSound();
  }
  
  // Apply gravity
  dinoVelocity += GRAVITY;
  dinoY += dinoVelocity;
  
  // Check ground collision
  if (dinoY >= GROUND_LEVEL - DINO_HEIGHT) {
    dinoY = GROUND_LEVEL - DINO_HEIGHT;
    dinoVelocity = 0;
    isJumping = false;
  }
  
  // Draw dino
  drawDino();
  
  // Update obstacles
  updateObstacles();
  
  // Check collisions
  if (checkCollision()) {
    gameOver();
    return;
  }
  
  // Update score
  updateScore();
  
  // Draw score
  drawScore();
}

void drawDino() {
  // Draw dino body
  tft.fillRect(dinoX, dinoY, DINO_WIDTH, DINO_HEIGHT, TFT_GREEN);
  
  // Draw dino eye
  tft.fillCircle(dinoX + 15, dinoY + 5, 2, TFT_WHITE);
  
  // Draw dino legs (animation based on position)
  if (millis() % 300 < 150) {
    tft.fillRect(dinoX + 5, dinoY + DINO_HEIGHT, 4, 5, TFT_GREEN); // Front leg
  } else {
    tft.fillRect(dinoX + 12, dinoY + DINO_HEIGHT, 4, 5, TFT_GREEN); // Back leg
  }
}

void drawGround() {
  tft.fillRect(0, GROUND_LEVEL, SCREEN_WIDTH, GROUND_HEIGHT, TFT_DARKGREY);
  
  // Draw ground pattern
  for (int i = 0; i < SCREEN_WIDTH; i += 10) {
    tft.drawFastVLine(i, GROUND_LEVEL + 5, GROUND_HEIGHT - 5, TFT_LIGHTGREY);
  }
}

void updateObstacles() {
  // Move and draw obstacles
  for (int i = 0; i < 3; i++) {
    if (obstacles[i].active) {
      // Move obstacle
      obstacles[i].x -= OBSTACLE_SPEED;
      
      // Draw obstacle (cactus)
      tft.fillRect(obstacles[i].x, obstacles[i].y, 
                  obstacles[i].width, obstacles[i].height, TFT_DARKGREEN);
      
      // Add cactus details
      tft.fillRect(obstacles[i].x + obstacles[i].width/2 - 2, 
                  obstacles[i].y - 5, 4, 5, TFT_DARKGREEN);
      
      // Deactivate if off-screen
      if (obstacles[i].x + obstacles[i].width < 0) {
        obstacles[i].active = false;
      }
    }
  }
  
  // Try to spawn new obstacle
  if (random(100) < 3) { // 3% chance each frame
    spawnObstacle();
  }
}

void spawnObstacle() {
  for (int i = 0; i < 3; i++) {
    if (!obstacles[i].active) {
      obstacles[i].x = SCREEN_WIDTH;
      obstacles[i].width = random(OBSTACLE_MIN_WIDTH, OBSTACLE_MAX_WIDTH);
      obstacles[i].height = random(OBSTACLE_MIN_HEIGHT, OBSTACLE_MAX_HEIGHT);
      obstacles[i].y = GROUND_LEVEL - obstacles[i].height;
      obstacles[i].active = true;
      break;
    }
  }
}

bool checkCollision() {
  for (int i = 0; i < 3; i++) {
    if (obstacles[i].active) {
      // Simple rectangle collision
      if (dinoX + DINO_WIDTH > obstacles[i].x && 
          dinoX < obstacles[i].x + obstacles[i].width &&
          dinoY + DINO_HEIGHT > obstacles[i].y) {
        return true;
      }
    }
  }
  return false;
}

void updateScore() {
  if (millis() - lastScoreTime > 100) { // Increase score every 100ms
    score++;
    lastScoreTime = millis();
  }
}

void drawScore() {
  tft.setTextColor(TFT_WHITE);
  tft.setTextSize(1);
  tft.setCursor(SCREEN_WIDTH - 50, 5);
  tft.print("Score: ");
  tft.print(score);
}

void gameOver() {
  gameState = STATE_GAME_OVER;
  
  // Play game over sound
  playGameOverSound();
  
  // Display game over message
  tft.fillScreen(TFT_BLACK);
  tft.setTextColor(TFT_RED);
  tft.setTextSize(2);
  tft.setCursor(70, 40);
  tft.print("GAME OVER");
  
  tft.setTextColor(TFT_WHITE);
  tft.setTextSize(1);
  tft.setCursor(80, 70);
  tft.print("Score: ");
  tft.print(score);
  
  // Update high score
  if (score > highScore) {
    highScore = score;
    tft.setCursor(80, 85);
    tft.print("New High Score!");
  } else {
    tft.setCursor(70, 85);
    tft.print("High Score: ");
    tft.print(highScore);
  }
  
  tft.setCursor(50, 110);
  tft.print("Press to restart");
}

void resetGame() {
  // Reset game variables
  dinoY = GROUND_LEVEL - DINO_HEIGHT;
  dinoVelocity = 0;
  isJumping = false;
  score = 0;
  lastScoreTime = millis();
  
  // Clear obstacles
  for (int i = 0; i < 3; i++) {
    obstacles[i].active = false;
  }
  
  // Clear screen
  tft.fillScreen(TFT_BLACK);
  drawGround();
}

void playJumpSound() {
  // Simple buzzer sound for jump
  tone(BUZZER_PIN, 523, 100); // C5 note for 100ms
}

void playGameOverSound() {
  // Game over sound
  tone(BUZZER_PIN, 349, 200); // F4
  delay(250);
  tone(BUZZER_PIN, 294, 400); // D4
}